"""Versioned, configurable detection data."""
